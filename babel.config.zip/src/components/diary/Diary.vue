<template>
    <!--====children 라우트(diary/detail, update, write)====-->
    <router-view></router-view>
</template>
<script>
export default ({
   name: 'Diary' 
});
</script>

