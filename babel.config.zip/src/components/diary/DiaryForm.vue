<template>
    <div>
        <div class="write-bar">
            <i class="el-icon-edit"></i>
            <strong>일기 작성</strong>
        </div>
        <el-divider></el-divider>
        <el-form :model = "diaryForm" class="demo-ruleForm" :rules = "rules" ref="diaryForm">
            <el-form-item label="제목" prop="title">
                <el-input v-model = "diaryForm.title"></el-input>
            </el-form-item>
            <el-form-item label="날씨" prop="weather">
                <el-radio-group v-model = "diaryForm.weather" >
                    <el-radio-button label="sunny"><i class="el-icon-sunny"></i></el-radio-button>
                    <el-radio-button label="cloudy"><i class="el-icon-cloudy"></i></el-radio-button>
                    <el-radio-button label="rain"><i class="el-icon-heavy-rain"></i></el-radio-button>
                    <el-radio-button label="snow"><i class="el-icon-light-rain"></i></el-radio-button>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="기분" prop="emotion">
                <el-select v-model = "diaryForm.emotion" placeholder="오늘의 기분">
                    <el-option label = "기쁨" value="기쁨"></el-option>
                    <el-option label = "우울" value="우울"></el-option>
                    <el-option label = "화남" value="화남"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="내용" prop="contents">
                <el-input type = "textarea" v-model = "diaryForm.contents"></el-input>
            </el-form-item>
                <el-button @click = "save('diaryForm')">저장</el-button>
                <el-button @click = "cancel">취소</el-button>
        </el-form>
    </div>
</template>
<script>
export default ({
    name: 'DiaryForm',
})
</script>
