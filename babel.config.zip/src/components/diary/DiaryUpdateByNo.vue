<template>
       <div class="wrapper">
        <div class="write-bar">
            <i class="el-icon-edit"></i>
            <strong>일기 수정</strong>
        </div>
        <el-divider></el-divider>
        <el-form :model = "diaryForm" class="demo-ruleForm" :rules = "rules" ref="diaryForm">
            <el-form-item label="제목" prop="title">
                <el-input v-model = "diaryForm.title"></el-input>
            </el-form-item>
            <el-form-item label="날씨" prop="weather">
                <el-radio-group v-model = "diaryForm.weather" >
                    <el-radio-button label="sunny" ><i class="el-icon-sunny"></i></el-radio-button>
                    <el-radio-button label="cloudy"><i class="el-icon-cloudy"></i></el-radio-button>
                    <el-radio-button label="rain"><i class="el-icon-heavy-rain"></i></el-radio-button>
                    <el-radio-button label="snow"><i class="el-icon-light-rain"></i></el-radio-button>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="기분" prop="emotion">
                <el-select v-model = "diaryForm.emotion" placeholder="오늘의 기분">
                    <el-option label = "기쁨" value="기쁨"></el-option>
                    <el-option label = "우울" value="우울"></el-option>
                    <el-option label = "화남" value="화남"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="내용" prop="contents">
                <el-input type = "textarea" v-model = "diaryForm.contents"  :rows = "20"></el-input>
            </el-form-item>
                <el-button @click = "save('diaryForm')">저장</el-button>
                <el-button @click = "cancel(diaryForm.id)">취소</el-button>
        </el-form>
    </div>
</template>
<script>

export default ({
    data() {
        return {
            updateDiary : null,
            rules: {
                title: [
                    { required: true, message: '제목을 입력하세요.', trigger: 'blur' },
                    { min: 3, max: 30, message: '3~30자 이내로 제목을 입력하세요.', trigger: 'blur' }
                ],
                weather: [
                    { required: true, message: '오늘의 날씨를 선택하세요.', trigger: 'change' }
                ],
                emotion: [
                    { required: true, message: '오늘의 기분을 선택하세요.', trigger: 'change' }
                ],
                contents: [
                    { required: true, message: '내용을 입력하세요', trigger: 'blur' },
                    { min: 10, max: 1000, message: '10~1000자 이내로 제목을 입력하세요.', trigger: 'blur' }
                ]
            }
        };
    },
    computed: {
        //현재 사용자의 일기목록 중 일기id와 일치하는 일기내용을 반환한다.
        diaryForm() {
            return this.$store.state.diaryList.filter(item => item.user === this.$store.state.currentUser&&item.id === this.$route.params.no)[0];        
        }
    },
    methods: {
        //입력한 수정내역을 변수에 담아 보내고, 수정내용을 저장한다.
        save(formName) {
             this.$refs[formName].validate((valid) => {
               if(valid) {
                this.updateDiary = Object.assign({},this.diary);
                console.log(Object.is(this.updateDiary, this.diary));
                this.$store.commit('updateOne', this.updateDiary);
                this.$router.push("/diary/list");
                this.$message({
                    message: '글이 수정되었습니다.',
                    type: 'success'
                });
               }else{
                   this.$message({
                        message: '내용을 다시 확인해주세요.',
                        type: 'warning'
                    });
                    return false;
               }
             })
        },
        cancel(id) {
            this.$router.push({ name: "DiaryDetailByNo", params: { no : id}})
        }
    }
})
</script>
<style scoped>
     .wrapper {
        margin: 50px auto;
        width: 60%;
    }
    .write-bar{
        text-align: left;
        font-size: 18px;
    }
    .el-form {
        padding-right: 50px;
    }
    .el-form-item{
        text-align: left;
    }
    .el-button {
        background : gold;
        box-shadow: none;
        color: white;
        font-size: 16px;
    }
</style>
